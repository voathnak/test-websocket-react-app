from utils.models.user import UserModel
from utils.orm import response
from utils.utils import log_event


def lambda_handler(event, context):
    log_event(event)
    # return response(200, "Hello, Welcome to VLIM Users service")

    user = UserModel()
    return user.rest_controller(event, context)

