class Message:
    type = {'online-user', 'health-check', 'message'}
    data = {
        "text": '',
        "id": '',
        "type": 'received'
    }
    time = ""
    username = ""
    profilePhoto = ""
